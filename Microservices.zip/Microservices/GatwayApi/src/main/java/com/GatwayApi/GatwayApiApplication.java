package com.GatwayApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class GatwayApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatwayApiApplication.class, args);
	}

}
