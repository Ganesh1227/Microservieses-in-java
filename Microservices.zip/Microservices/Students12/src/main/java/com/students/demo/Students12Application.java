package com.students.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class Students12Application {

	public static void main(String[] args) {
		SpringApplication.run(Students12Application.class, args);
	}

}
