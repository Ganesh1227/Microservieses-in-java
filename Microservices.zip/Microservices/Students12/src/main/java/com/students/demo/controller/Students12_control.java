package com.students.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.students.demo.entity.Students12_entity;
import com.students.demo.services.Students12_services;



import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PutMapping;




@RestController
@RequestMapping("/students12")
public class Students12_control {
	@Autowired
	Students12_services students12_services;
	
	
	@PostMapping("/posting")
	public String postMethodName(@RequestBody Students12_entity id) {
		//TODO: process POST request
		
		return students12_services.create( id);
	}
	
	@GetMapping("/getting")
	public Iterable<Students12_entity> getMethodName() {
		return students12_services.reading();
	}
	
	@DeleteMapping("/deleting/{id}")
	public String delet(@PathVariable Integer id)
	{
		 return students12_services.delet(id);
		
	}
	
	@PutMapping("/updating/{id}")
	public Students12_entity putMethodName(@PathVariable int id, @RequestBody Students12_entity rd) {
		//TODO: process PUT request
		
		return students12_services.updating(id,rd);
	}
	

}
