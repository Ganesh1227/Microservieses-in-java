package com.students.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Students12_entity {
	
	@Id
	Integer id;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	String name;
	public Students12_entity() {
		super();
		// TODO Auto-generated constructor stub
	}

	Integer roll_no;
	 String division ;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getRoll_no() {
		return roll_no;
	}
	public void setRoll_no(Integer roll_no) {
		this.roll_no = roll_no;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	
	public Students12_entity(String name, Integer roll_no, String division,Integer id) {
		super();
		this.id=id;
		this.name = name;
		this.roll_no = roll_no;
		this.division = division;
	}
	

}
