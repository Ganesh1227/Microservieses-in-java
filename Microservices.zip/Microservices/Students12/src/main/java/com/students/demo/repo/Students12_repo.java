package com.students.demo.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.students.demo.entity.Students12_entity;

@Repository
public interface Students12_repo  extends CrudRepository<Students12_entity, Integer>{

	
}
