package com.students.demo.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.students.demo.entity.Students12_entity;
import com.students.demo.exception.ResourceNotFoundException;
import com.students.demo.repo.Students12_repo;

@Service
public class Students12_services {

	@Autowired
	Students12_repo students12_repo;

	public String create(Students12_entity id) {
		students12_repo.save(id);
		return "Record saved succesfully....";

	}

	public Iterable<Students12_entity> reading() {
		return students12_repo.findAll();

	}

	public String delet(Integer id) {
		
		Optional<Students12_entity> stud = students12_repo.findById(id);
		if (stud.isEmpty()) {
			return "no such record found!";
		} 
		stud.get();
		students12_repo.deleteById(id);
		return "deleting..";

	}

	public Students12_entity updating(int id, Students12_entity rd) {
		Students12_entity stud = students12_repo.findById(id).get();
		if (rd.getId() != null)
			stud.setId(rd.getId());
		if (rd.getName() != null)
			stud.setName(rd.getName());
		if (rd.getRoll_no() != null)
			stud.setRoll_no(rd.getRoll_no());
		if (rd.getDivision()!=null)
			stud.setDivision(rd.getDivision());
		
			return students12_repo.save(stud);
		

	}
}
