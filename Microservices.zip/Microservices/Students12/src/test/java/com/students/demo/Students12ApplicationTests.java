package com.students.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Students12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
