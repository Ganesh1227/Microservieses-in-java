package com.students.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.students.demo.entity.Students13_entity;
import com.students.demo.services.Students13_services;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/students13")
public class Students13_control {
	@Autowired
	
	Students13_services students13_services;
	
	@PostMapping("/posting")
	public Students13_entity postMethodName(@RequestBody Students13_entity entity) {
		
		return students13_services.creat(entity);
	}
	@GetMapping("getting/{id}")
	public Optional<Students13_entity> getMethodName(@RequestParam int id) {
		return  students13_services.getstud(id);
	}
	
	@DeleteMapping("/deleting/{id}")
	public String deleting( int id)
	{
		return students13_services.delet(id);
	}
	@PutMapping("updating/{id}")
	public Students13_entity putMethodName(@PathVariable int id, @RequestBody Students13_entity  entity) {
		return students13_services.update(id,entity);
		
		
	}
	
	

}
