package com.students.demo.repositari;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.students.demo.entity.Students13_entity;

@Repository
public interface Students13_repo  extends CrudRepository<Students13_entity, Integer>{

	
}
