package com.students.demo.services;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.students.demo.entity.Students13_entity;
import com.students.demo.repositari.Students13_repo;

@Service
public class Students13_services {

	@Autowired
	Students13_repo students13_repo;
	
	public Students13_entity creat(Students13_entity entity)
	{
		return students13_repo.save(entity);
	}
	
	public Optional<Students13_entity> getstud(int id)
	{
		return students13_repo.findById(id);
	}
	public String delet(int id)
	{
		students13_repo.deleteById(id);
		return "deleted succesffulyy....";
	}
	public Students13_entity update(int id,Students13_entity en)
	{
		Students13_entity enti=students13_repo.findById(id).orElseThrow();
		if(enti!=null)
		{
			enti.setId(en.getId());
			enti.setName(en.getName());
			enti.setRoll_no(en.getRoll_no());
			enti.setDivision(en.getDivision());
		}
		return students13_repo.save(enti);
	}
}
